﻿
namespace MainClient
{
    public enum CharacterAction
    {
        UNDEFINED = 0,
        IDLE = 1,
        RUN = 2,
        ATTACK1 = 3,
        ATTACK2 = 4,
        ATTACK3 = 5,
    }
}
